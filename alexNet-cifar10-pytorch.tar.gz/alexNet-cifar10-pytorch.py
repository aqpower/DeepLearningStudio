#!/usr/bin/env python
# coding: utf-8

# In[129]:


import time

import numpy as np
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from torchvision import transforms
from torchvision.datasets import CIFAR10


# In[130]:


# 定义超参数
batch_size = 128
learning_rate = 0.0001
num_epochs = 20
num_classes = 10


# 检查 GPU 是否可用
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print("Using device:", device)
if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

classes = (
    "Airplane",
    "Car",
    "Bird",
    "Cat",
    "Deer",
    "Dog",
    "Frog",
    "Horse",
    "Ship",
    "Truck",
)


# In[131]:


# Define the transformation to apply to the data
transform = transforms.Compose(
    [
        transforms.Resize(224),
        transforms.ToTensor(),  # Convert PIL Image to tensor 将图像转换为张量并缩放到 [0.0, 1.0]
        # 将 CIFAR-10 数据集的图像标准化，使得每个通道的均值为 0，标准差为 1。
        # 这样可以帮助模型更快地收敛，提高训练效率。
        transforms.Normalize(
            (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)
        ),  # Normalize the data
    ]
)

# Load the CIFAR-10 training dataset
train_data = CIFAR10(root="./", train=True, download=True, transform=transform)
train_loader = DataLoader(
    train_data, batch_size=batch_size, shuffle=True, num_workers=2
)

# Load the CIFAR-10 testing dataset
test_data = CIFAR10(root="./", train=False, transform=transform)
test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False, num_workers=2)


# In[132]:


# Checking the dataset
print("Training Set:")
for images, labels in train_loader:
    print("Image batch dimensions:", images.size())
    print("Image label dimensions:", labels.size())
    print(labels[:10])
    break

# Checking the dataset
print("Testing Set:")
for images, labels in train_loader:
    print("Image batch dimensions:", images.size())
    print("Image label dimensions:", labels.size())
    print(labels[:10])
    break


# In[133]:


class AlexNet(nn.Module):

    def __init__(self, num_classes=num_classes):
        super(AlexNet, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 96, kernel_size=11, stride=4, padding=2),
            # 原地操作，即直接覆盖原输入
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            
            nn.Conv2d(96, 256, kernel_size=5, stride=1, padding=2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
            
            nn.Conv2d(256, 384, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            
            nn.Conv2d(384, 384, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            
            nn.Conv2d(384, 256, kernel_size=3, stride=1, padding=1),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2),
        )
        self.classifier = nn.Sequential(
            nn.Dropout(),
            nn.Linear(256 * 6 * 6, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


# In[134]:


# 创建模型实例
model = AlexNet()
model.to(device)

# 定义损失函数和优化器
loss_fn = loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)


# In[135]:


def compute_accuracy(model, data_loader):
    model.eval()
    with torch.no_grad():
        correct_pred, num_examples = 0, 0
        for i, (features, targets) in enumerate(data_loader):
            features = features.to(device)
            targets = targets.to(device)

            # 计算模型输出
            outputs = model(features)
            _, predicted_labels = torch.max(outputs, 1)

            # 统计正确预测的数量和样本总数
            num_examples += targets.size(0)
            correct_pred += (predicted_labels == targets).sum()
    return correct_pred * 1.0 / num_examples * 100


def compute_epoch_loss(model, data_loader):
    model.eval()
    curr_loss, num_examples = 0.0, 0
    with torch.no_grad():
        for features, targets in data_loader:
            features = features.to(device)
            targets = targets.to(device)
            outputs = model(features)
            loss = F.cross_entropy(outputs, targets, reduction="sum")
            num_examples += targets.size(0)
            curr_loss += loss

    curr_loss = curr_loss / num_examples
    return curr_loss


# In[136]:


log_dict = {
    "train_loss_per_batch": [],
    "train_acc_per_epoch": [],
    "train_loss_per_epoch": [],
}
# 训练模型
start_time = time.time()
for epoch in range(num_epochs):  # 遍历数据集多次
    model.train()
    for batch_idx, (features, targets) in enumerate(train_loader, 0):
        # 获取输入数据
        features = features.to(device)
        targets = targets.to(device)

        # FORWARD AND BACK PROP
        logits = model(features)
        if isinstance(logits, torch.distributed.rpc.api.RRef):
            logits = logits.local_value()
        loss = loss_fn(logits, targets)
        optimizer.zero_grad()

        loss.backward()

        # UPDATE MODEL PARAMETERS
        optimizer.step()

        # LOGGING
        log_dict["train_loss_per_batch"].append(loss.item())
        if not batch_idx % 50:
            print(
                f"Epoch: {epoch+1:03d}/{num_epochs:03d} | Batch {batch_idx:04d}/{len(train_loader):04d} | Loss: {loss:.4f}"
            )

    model.eval()

    with torch.set_grad_enabled(False):  # save memory during inference
        train_acc = compute_accuracy(model, train_loader)
        train_loss = compute_epoch_loss(model, train_loader)
        print(
            f"***Epoch: {epoch+1:03d}/{num_epochs:03d} | Train. Acc.: {train_acc:.3f}% | Loss: {train_loss:.3f}"
        )
        log_dict["train_loss_per_epoch"].append(train_loss.item())
        log_dict["train_acc_per_epoch"].append(train_acc.item())

    print(f"Time elapsed: {(time.time() - start_time) / 60:.2f} min")

print(f"Total Training Time: {(time.time() - start_time)/ 60:.2f} min")


# In[ ]:


loss_list = log_dict["train_loss_per_batch"]

plt.plot(loss_list, label="Minibatch loss")
plt.plot(
    np.convolve(
        loss_list,
        np.ones(200,) / 200,
        mode="valid",
    ),
    label="Running average",
)

plt.ylabel("Cross Entropy")
plt.xlabel("Iteration")
plt.legend()
plt.savefig("loss.svg", format="svg")
plt.show()
plt.close()


# In[ ]:


plt.figure(figsize=(10, 6)) 
plt.plot(
    np.arange(1, num_epochs + 1),
    log_dict["train_acc_per_epoch"],
    label="Training Accuracy",
    color="blue",  
    linestyle="-",  
    marker="o",  # 设置标记样式
    markersize=6,  
    linewidth=2,  
)

plt.xlabel("Epoch", fontsize=14)  
plt.ylabel("Accuracy (%)", fontsize=14)  
plt.title("Training Accuracy per Epoch", fontsize=16)  
plt.legend(loc="best", fontsize=12)  

plt.grid(True)  
plt.tight_layout()  

# 保存图像
plt.savefig("accuracy.svg", format="svg") 
plt.show()  


# In[ ]:


with torch.set_grad_enabled(False):
    train_acc = compute_accuracy(model=model, data_loader=train_loader)
    test_acc = compute_accuracy(model=model, data_loader=test_loader)



print(f"Train ACC: {train_acc:.2f}%")
print(f"Test ACC: {test_acc:.2f}%")

